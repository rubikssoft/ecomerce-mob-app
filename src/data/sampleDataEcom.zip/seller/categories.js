export const categories = [
    {
        id: 1,
        name: 'Grocerry',

    },
    {
        id: 2,
        name: 'Vegitables'
    },

    {
        id: 3,
        name: 'Fruites'
    },

    {
        id: 4,
        name: 'Rice'
    }
]