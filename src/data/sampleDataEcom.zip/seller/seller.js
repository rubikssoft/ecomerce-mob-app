export const seller = {
    id: 32,
    name: 'Test Shop',
    place: 'Mukkam ',
    category: 'Grocery , Test Cate1 ',
    phone: '98765433455',
    img: 'http://www.shpanda.com/uploads/allimg/130723/1-130H3214S30-L.jpg'
}