export const subcategories = [
    {
        id: 1,
        category: 3,
        name: 'Mutta',

    },
    {
        id: 2,
        category: 3,
        name: 'Kuruva'
    },

    {
        id: 3,
        category: 3,
        name: 'Jaya'
    },

    {
        id: 4,
        category: 3,
        name: 'Ponni'
    },

    {
        id: 5,
        category: 3,
        name: 'Kaima'
    }
]