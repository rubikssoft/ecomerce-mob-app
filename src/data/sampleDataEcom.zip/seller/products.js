export const products = [
    {
        id: 2,
        category: 3,
        name: 'Rice 2',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    },
    {
        id: 3,
        category: 3,
        name: 'Rice 3',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 4,
        category: 3,
        name: 'Rice 4',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 5,
        category: 3,
        name: 'Rice 5',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]

    },

    {
        id: 2,
        category: 3,
        name: 'Rice 2',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    },
    {
        id: 3,
        category: 3,
        name: 'Rice 3',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 4,
        category: 3,
        name: 'Rice 4',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 5,
        category: 3,
        name: 'Rice 5',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]

    },


    {
        id: 2,
        category: 3,
        name: 'Rice 2',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    },
    {
        id: 3,
        category: 3,
        name: 'Rice 3',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 4,
        category: 3,
        name: 'Rice 4',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 5,
        category: 3,
        name: 'Rice 5',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]

    }, {
        id: 2,
        category: 3,
        name: 'Rice 2',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    },
    {
        id: 3,
        category: 3,
        name: 'Rice 3',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 4,
        category: 3,
        name: 'Rice 4',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 5,
        category: 3,
        name: 'Rice 5',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]

    },
    {
        id: 2,
        category: 3,
        name: 'Rice 2',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    },
    {
        id: 3,
        category: 3,
        name: 'Rice 3',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 4,
        category: 3,
        name: 'Rice 4',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]
    }, {
        id: 5,
        category: 3,
        name: 'Rice 5',
        category: 'Raice',
        price: 20,
        unit: [
            { name: 'gm', default: false, value: 0.001 },
            { name: 'kg', default: true, value: 1, }
        ]

    },



]